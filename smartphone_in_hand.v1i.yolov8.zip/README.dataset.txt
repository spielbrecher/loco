# smartphone_in_hand > 2023-09-24 12:45am
https://universe.roboflow.com/spielbrecher/smartphone_in_hand

Provided by a Roboflow user
License: CC BY 4.0

